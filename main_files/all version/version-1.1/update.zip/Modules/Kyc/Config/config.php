<?php

return [
    'name' => 'Kyc'
];
